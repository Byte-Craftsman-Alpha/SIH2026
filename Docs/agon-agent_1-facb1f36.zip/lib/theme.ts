import { useColorScheme } from 'react-native';

export type AppTheme = {
  dark: boolean;
  colors: {
    canvas: string;
    surface: string;
    surfaceAlt: string;
    text: string;
    muted: string;
    subtle: string;
    line: string;
    primary: string;
    primaryDark: string;
    primarySoft: string;
    amber: string;
    amberSoft: string;
    danger: string;
    dangerSoft: string;
    blue: string;
    blueSoft: string;
    shadow: string;
  };
};

const light: AppTheme = {
  dark: false,
  colors: {
    canvas: '#F6F8F4',
    surface: '#FFFFFF',
    surfaceAlt: '#EDF3EF',
    text: '#17221F',
    muted: '#68766F',
    subtle: '#93A099',
    line: '#E1E8E3',
    primary: '#0E7567',
    primaryDark: '#07594F',
    primarySoft: '#DDF2EA',
    amber: '#C97419',
    amberSoft: '#FFF0DB',
    danger: '#C94343',
    dangerSoft: '#FCE8E6',
    blue: '#3975A6',
    blueSoft: '#E5F0FA',
    shadow: '#18352E',
  },
};

const dark: AppTheme = {
  dark: true,
  colors: {
    canvas: '#0D1513',
    surface: '#17211F',
    surfaceAlt: '#1F2C28',
    text: '#F2F7F4',
    muted: '#A7B5AE',
    subtle: '#74827C',
    line: '#2B3935',
    primary: '#63C6AE',
    primaryDark: '#3FA38C',
    primarySoft: '#173F36',
    amber: '#F0AC59',
    amberSoft: '#3C2C18',
    danger: '#FF8580',
    dangerSoft: '#452625',
    blue: '#8DC2EE',
    blueSoft: '#20384D',
    shadow: '#000000',
  },
};

export function useAppTheme(): AppTheme {
  return useColorScheme() === 'dark' ? dark : light;
}
