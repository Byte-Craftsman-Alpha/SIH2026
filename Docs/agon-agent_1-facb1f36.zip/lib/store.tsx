import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, ReactNode, useContext, useEffect, useMemo, useState } from 'react';

export type MedicalRecord = {
  id: string;
  title: string;
  provider: string;
  date: string;
  uploadedAt: string;
  type: string;
  status: 'Reviewed' | 'Attention' | 'Healthy';
  summary: string;
  findings: string[];
  imageUri?: string;
  doctorConfirmed?: boolean;
};

export type Appointment = {
  id: string;
  doctor: string;
  specialty: string;
  date: string;
  time: string;
  mode: 'Video' | 'In clinic';
  urgent?: boolean;
  location: string;
};

export type EmergencyProfile = {
  bloodGroup: string;
  allergies: string;
  diabetes: string;
  gender: string;
  age: string;
  address: string;
  emergencyContact: string;
  conditions: string;
};

type HealthStore = {
  records: MedicalRecord[];
  appointments: Appointment[];
  emergency: EmergencyProfile;
  hydrated: boolean;
  addRecord: (record: MedicalRecord) => void;
  updateRecord: (record: MedicalRecord) => void;
  addAppointment: (appointment: Appointment) => void;
  updateEmergency: (profile: EmergencyProfile) => void;
};

const initialRecords: MedicalRecord[] = [
  {
    id: 'r-1',
    title: 'Lipid & metabolic panel',
    provider: 'Sunrise Diagnostics',
    date: '28 Aug 2026',
    uploadedAt: '28 Aug 2026 · 6:42 PM',
    type: 'Lab report',
    status: 'Attention',
    summary: 'Most markers are within range. HbA1c is slightly elevated and worth discussing at your next visit.',
    findings: ['HbA1c · 6.1% · slightly high', 'LDL · 104 mg/dL · near optimal', 'Triglycerides · 138 mg/dL · normal'],
  },
  {
    id: 'r-2',
    title: 'Ayurvedic consultation',
    provider: 'Aarogya AYUSH Centre',
    date: '16 Aug 2026',
    uploadedAt: '16 Aug 2026 · 11:10 AM',
    type: 'Consultation note',
    status: 'Reviewed',
    summary: 'Pitta-predominant Vikriti with irregular Agni. Cooling meals and a consistent sleep routine were advised.',
    findings: ['Prakriti · Vata–Pitta', 'Vikriti · Pitta dominant', 'Agni · Vishama'],
  },
  {
    id: 'r-3',
    title: 'Complete blood count',
    provider: 'CityCare Labs',
    date: '02 Jul 2026',
    uploadedAt: '02 Jul 2026 · 9:18 AM',
    type: 'Lab report',
    status: 'Healthy',
    summary: 'All measured blood-count markers are within the stated laboratory reference ranges.',
    findings: ['Haemoglobin · 14.2 g/dL', 'WBC · 7,100 /µL', 'Platelets · 2.54 lakh/µL'],
  },
];

const initialAppointments: Appointment[] = [
  {
    id: 'a-1',
    doctor: 'Dr. Meera Iyer',
    specialty: 'Ayurveda · BAMS, MD',
    date: '08 Sep 2026',
    time: '10:30 AM',
    mode: 'Video',
    location: 'Vitala secure video',
  },
  {
    id: 'a-2',
    doctor: 'Dr. Rohan Kapoor',
    specialty: 'General Medicine · MD',
    date: '14 Sep 2026',
    time: '4:00 PM',
    mode: 'In clinic',
    location: 'WellSpring Clinic · Indiranagar',
  },
];

const initialEmergency: EmergencyProfile = {
  bloodGroup: 'O+',
  allergies: 'Penicillin',
  diabetes: 'Prediabetic',
  gender: 'Male',
  age: '34',
  address: 'Indiranagar, Bengaluru',
  emergencyContact: 'Nisha · +91 98765 43210',
  conditions: 'Mild asthma',
};

const STORAGE_KEY = '@vitala/health-store-v1';
const StoreContext = createContext<HealthStore | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [records, setRecords] = useState(initialRecords);
  const [appointments, setAppointments] = useState(initialAppointments);
  const [emergency, setEmergency] = useState(initialEmergency);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY)
      .then((value) => {
        if (!value) return;
        const saved = JSON.parse(value) as Partial<Pick<HealthStore, 'records' | 'appointments' | 'emergency'>>;
        if (saved.records) setRecords(saved.records);
        if (saved.appointments) setAppointments(saved.appointments);
        if (saved.emergency) setEmergency(saved.emergency);
      })
      .catch(() => undefined)
      .finally(() => setHydrated(true));
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({ records, appointments, emergency })).catch(() => undefined);
  }, [records, appointments, emergency, hydrated]);

  const value = useMemo<HealthStore>(
    () => ({
      records,
      appointments,
      emergency,
      hydrated,
      addRecord: (record) => setRecords((current) => [record, ...current]),
      updateRecord: (record) => setRecords((current) => current.map((item) => item.id === record.id ? record : item)),
      addAppointment: (appointment) => setAppointments((current) => [appointment, ...current]),
      updateEmergency: setEmergency,
    }),
    [records, appointments, emergency, hydrated],
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useHealthStore() {
  const context = useContext(StoreContext);
  if (!context) throw new Error('useHealthStore must be used inside AppProvider');
  return context;
}
